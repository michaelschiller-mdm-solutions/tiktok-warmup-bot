/*
 * Markt.de Premium Followed Accounts Scraper
 * 
 * This script extracts premium accounts from the "mir gefallen" section for each target account.
 * For each target account, it navigates to their profile and extracts all premium accounts they follow.
 * If no premium accounts are found, it extracts 5 normal accounts and marks them as premium: false.
 * 
 * Installation:
 * npm install playwright
 * npx playwright install chromium
 * 
 * Usage:
 * node premium-followed-scraper.js
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// Configuration
const CONFIG = {
    delays: {
        pageLoad: 2000,         // Wait for page to load
        modalLoad: 1500,        // Wait for modal to open
        loadMore: 800,          // Wait between "Mehr Likes laden" clicks
        extraction: 200,        // Wait between account extractions
        betweenProfiles: 1500,  // Wait between different target profiles
        sessionBreak: 300000    // 5 minutes between sessions
    },
    
    selectors: {
        hostButton: '.clsy-profile__likes-dialog-i-them', // "mir gefallen" button
        modal: '.clsy-c-dialog__body',
        loadMoreButton: '.clsy-c-endlessScrolling--hasMore',
        accountBox: '.clsy-c-userbox',
        premiumIndicator: '.clsy-profile-image--premium',
        profileImage: '.clsy-profile-image',
        profileName: '.clsy-c-userbox__profile-name',
        closeButton: '.clsy-c-dialog__close, [aria-label="Close"]'
    },
    
    csv: {
        inputFilename: './target_accounts.csv',
        outputFilename: './premium_followed_by.csv',
        processedFilename: './premium_processed_targets.csv',
        batchSize: 5  // Save every 5 accounts for more frequent saves
    },
    
    session: {
        maxAccountsPerSession: 50,  // Process 50 target accounts per session
        sessionBreakMinutes: 5,     // Break between sessions
        maxRetries: 3,              // Retry failed accounts
        resumeFromLast: true        // Resume from last processed account
    },
    
    browser: {
        headless: true,         // Run in background by default
        slowMo: 100,           // Faster execution for background mode
        viewport: { width: 1280, height: 720 }
    },
    
    limits: {
        maxPremiumAccounts: 50,  // Max premium accounts to extract per target
        fallbackNormalAccounts: 5, // Number of normal accounts if no premium found
        maxLoadMoreClicks: 100   // Safety limit for pagination
    }
};

// Utility functions
class Utils {
    static log(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const prefix = `[${timestamp}] Premium Scraper:`;
        
        switch(type) {
            case 'error':
                console.error(`${prefix} ❌ ${message}`);
                break;
            case 'success':
                console.log(`${prefix} ✅ ${message}`);
                break;
            case 'warning':
                console.warn(`${prefix} ⚠️ ${message}`);
                break;
            default:
                console.log(`${prefix} ℹ️ ${message}`);
        }
    }

    static sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    static sanitizeForCSV(text) {
        if (!text) return '';
        
        // Remove any existing quotes and escape special characters
        let sanitized = text.replace(/"/g, '""');
        
        // Wrap in quotes if contains comma, newline, or quote
        if (sanitized.includes(',') || sanitized.includes('\n') || sanitized.includes('"')) {
            sanitized = `"${sanitized}"`;
        }
        
        return sanitized;
    }
}

// CSV Manager Class
class PremiumCSVManager {
    constructor() {
        this.processedPairs = new Set(); // Track target_account + followed_account pairs
        this.processedTargets = new Set(); // Track processed target accounts
        this.pendingAccounts = [];
        this.ensureCSVHeaders();
        this.loadProcessedTargets();
    }
    
    ensureCSVHeaders() {
        const header = 'target_account,target_account_id,followed_account,followed_account_id,is_premium,profile_image_url,profile_link\n';
        const processedHeader = 'target_account,target_account_id,status,timestamp,premium_found,total_followed\n';
        
        // Create output CSV if it doesn't exist
        if (!fs.existsSync(CONFIG.csv.outputFilename)) {
            fs.writeFileSync(CONFIG.csv.outputFilename, header);
            Utils.log(`Created ${CONFIG.csv.outputFilename}`);
        }
        
        // Create processed targets CSV if it doesn't exist
        if (!fs.existsSync(CONFIG.csv.processedFilename)) {
            fs.writeFileSync(CONFIG.csv.processedFilename, processedHeader);
            Utils.log(`Created ${CONFIG.csv.processedFilename}`);
        }
        
        // Load existing pairs to prevent duplicates
        this.loadExistingPairs();
    }
    
    loadExistingPairs() {
        try {
            if (fs.existsSync(CONFIG.csv.outputFilename)) {
                const content = fs.readFileSync(CONFIG.csv.outputFilename, 'utf8');
                const lines = content.split('\n').slice(1); // Skip header
                lines.forEach(line => {
                    if (line.trim()) {
                        const parts = line.split(',');
                        if (parts.length >= 4) {
                            const pairKey = `${parts[1]}_${parts[3]}`; // target_id_followed_id
                            this.processedPairs.add(pairKey);
                        }
                    }
                });
            }
            
            Utils.log(`Loaded ${this.processedPairs.size} existing account pairs`);
        } catch (error) {
            Utils.log(`Error loading existing pairs: ${error.message}`, 'warning');
        }
    }
    
    addAccountsToBatch(targetAccount, followedAccounts) {
        if (!followedAccounts || followedAccounts.length === 0) {
            return 0;
        }
        
        const newAccounts = followedAccounts.filter(account => {
            const pairKey = `${targetAccount.userId}_${account.userId}`;
            if (this.processedPairs.has(pairKey)) {
                return false;
            }
            this.processedPairs.add(pairKey);
            return true;
        });
        
        if (newAccounts.length === 0) {
            return 0;
        }
        
        // Add target account info to each followed account
        const enrichedAccounts = newAccounts.map(account => ({
            target_account: targetAccount.name,
            target_account_id: targetAccount.userId,
            followed_account: account.name,
            followed_account_id: account.userId,
            is_premium: account.isPremium,
            profile_image_url: account.profileImageUrl || '',
            profile_link: account.link
        }));
        
        // Add to pending batch
        this.pendingAccounts.push(...enrichedAccounts);
        
        // Save batch if it reaches the limit
        if (this.pendingAccounts.length >= CONFIG.csv.batchSize) {
            this.saveBatch();
        }
        
        return newAccounts.length;
    }
    
    saveBatch() {
        if (this.pendingAccounts.length === 0) {
            return 0;
        }
        
        // Append to CSV file
        const csvRows = this.pendingAccounts.map(account => 
            `${Utils.sanitizeForCSV(account.target_account)},${account.target_account_id},${Utils.sanitizeForCSV(account.followed_account)},${account.followed_account_id},${account.is_premium},${Utils.sanitizeForCSV(account.profile_image_url)},${Utils.sanitizeForCSV(account.profile_link)}`
        ).join('\n') + '\n';
        
        fs.appendFileSync(CONFIG.csv.outputFilename, csvRows);
        Utils.log(`💾 Batch saved: ${this.pendingAccounts.length} premium followed accounts`, 'success');
        
        // Clear the batch
        const savedCount = this.pendingAccounts.length;
        this.pendingAccounts = [];
        
        return savedCount;
    }
    
    saveAllPendingBatches() {
        const totalSaved = this.saveBatch();
        
        if (totalSaved > 0) {
            Utils.log(`💾 Final batch save: ${totalSaved} accounts saved`, 'success');
        }
        
        return totalSaved;
    }
    
    loadProcessedTargets() {
        try {
            if (fs.existsSync(CONFIG.csv.processedFilename)) {
                const content = fs.readFileSync(CONFIG.csv.processedFilename, 'utf8');
                const lines = content.split('\n').slice(1); // Skip header
                lines.forEach(line => {
                    if (line.trim()) {
                        const parts = line.split(',');
                        if (parts.length >= 2) {
                            this.processedTargets.add(parts[1]); // Add target_account_id
                        }
                    }
                });
            }
            
            Utils.log(`Loaded ${this.processedTargets.size} processed target accounts`);
        } catch (error) {
            Utils.log(`Error loading processed targets: ${error.message}`, 'warning');
        }
    }
    
    markTargetAsProcessed(targetAccount, premiumFound, totalFollowed, status = 'completed') {
        const timestamp = new Date().toISOString();
        const csvRow = `${Utils.sanitizeForCSV(targetAccount.name)},${targetAccount.userId},${status},${timestamp},${premiumFound},${totalFollowed}\n`;
        
        fs.appendFileSync(CONFIG.csv.processedFilename, csvRow);
        this.processedTargets.add(targetAccount.userId);
        
        Utils.log(`📝 Marked ${targetAccount.name} as ${status} (${premiumFound} premium, ${totalFollowed} total)`);
    }
    
    isTargetProcessed(targetAccount) {
        return this.processedTargets.has(targetAccount.userId);
    }
}

// Target Account Loader
class TargetAccountLoader {
    static loadTargetAccounts() {
        try {
            if (!fs.existsSync(CONFIG.csv.inputFilename)) {
                throw new Error(`Target accounts file not found: ${CONFIG.csv.inputFilename}`);
            }
            
            const content = fs.readFileSync(CONFIG.csv.inputFilename, 'utf8');
            const lines = content.split('\n').slice(1); // Skip header
            
            const accounts = [];
            lines.forEach((line, index) => {
                if (line.trim()) {
                    // Split by comma but handle the URL that contains commas
                    const parts = line.split(',');
                    if (parts.length >= 4) {
                        let name = parts[0];
                        let userId = parts[1];
                        
                        // Handle quoted names first
                        if (name.startsWith('"')) {
                            // Find the closing quote
                            let fullName = name;
                            let partIndex = 1;
                            while (!fullName.endsWith('"') && partIndex < parts.length) {
                                fullName += ',' + parts[partIndex];
                                partIndex++;
                            }
                            name = fullName.replace(/^"|"$/g, '').replace(/""/g, '"');
                            userId = parts[partIndex];
                            
                            // Reconstruct the full URL from the remaining parts after the quoted name
                            // Format: https://www.markt.de/username/userId,12345/profile.htm
                            let urlParts = parts.slice(partIndex + 1);
                            let profileUrl = urlParts.join(',').trim();
                            
                            accounts.push({
                                name: name,
                                userId: userId,
                                link: profileUrl,
                                profileUrl: profileUrl
                            });
                        } else {
                            // No quoted name - reconstruct URL from parts 2 onwards
                            // Format: name,userId,https://www.markt.de/username/userId,12345/profile.htm
                            let urlParts = parts.slice(2);
                            let profileUrl = urlParts.join(',').trim();
                            
                            accounts.push({
                                name: name,
                                userId: userId,
                                link: profileUrl,
                                profileUrl: profileUrl
                            });
                        }
                        
                        // Debug: log first few URLs to verify format
                        if (accounts.length <= 3) {
                            Utils.log(`Debug - Account ${accounts.length}: ${accounts[accounts.length-1].name} -> ${accounts[accounts.length-1].profileUrl}`);
                        }
                    }
                }
            });
            
            Utils.log(`Loaded ${accounts.length} target accounts from ${CONFIG.csv.inputFilename}`);
            return accounts;
            
        } catch (error) {
            Utils.log(`Error loading target accounts: ${error.message}`, 'error');
            throw error;
        }
    }
}

// Premium Account Extractor
class PremiumAccountExtractor {
    static async extractPremiumAccountsFromPage(page) {
        return await page.evaluate((selectors) => {
            const accounts = [];
            const accountBoxes = document.querySelectorAll(selectors.accountBox);
            
            accountBoxes.forEach((box, index) => {
                try {
                    const link = box.getAttribute('href');
                    
                    // Skip anonymous accounts
                    if (!link || link === '#') {
                        return;
                    }
                    
                    const nameElement = box.querySelector(selectors.profileName);
                    if (!nameElement) {
                        return;
                    }
                    
                    const name = nameElement.textContent.trim();
                    const userIdMatch = link.match(/userId,(\d+)/);
                    const userId = userIdMatch ? userIdMatch[1] : null;
                    
                    if (!userId || !name) {
                        return;
                    }
                    
                    // Check if account is premium - look for the specific premium class
                    const profileImageContainer = box.querySelector(selectors.profileImage);
                    const isPremium = profileImageContainer && profileImageContainer.classList.contains('clsy-profile-image--premium');
                    
                    // Get profile image URL
                    let profileImageUrl = '';
                    if (profileImageContainer) {
                        const imgElement = profileImageContainer.querySelector('img');
                        if (imgElement) {
                            profileImageUrl = imgElement.src || '';
                        }
                    }
                    
                    accounts.push({
                        name: name,
                        userId: userId,
                        link: link,
                        isPremium: isPremium,
                        profileImageUrl: profileImageUrl
                    });
                    
                } catch (error) {
                    console.log(`Error extracting account at index ${index}:`, error);
                }
            });
            
            return accounts;
        }, CONFIG.selectors);
    }
    
    static filterPremiumAccounts(accounts) {
        return accounts.filter(account => account.isPremium);
    }
    
    static getFallbackAccounts(accounts, count = CONFIG.limits.fallbackNormalAccounts) {
        const normalAccounts = accounts.filter(account => !account.isPremium);
        return normalAccounts.slice(0, count).map(account => ({
            ...account,
            isPremium: false // Explicitly mark as non-premium
        }));
    }
}

// Modal Handler Class
class PremiumModalHandler {
    static async openMirGefallenModal(page) {
        Utils.log('Opening "mir gefallen" modal...');
        
        // Wait for button to be visible and click it
        await page.waitForSelector(CONFIG.selectors.hostButton, { timeout: 10000 });
        await page.click(CONFIG.selectors.hostButton);
        
        // Wait for modal to appear
        await page.waitForSelector(CONFIG.selectors.modal, { timeout: 10000 });
        await Utils.sleep(CONFIG.delays.modalLoad);
        
        Utils.log('"mir gefallen" modal opened successfully');
    }
    
    static async loadAllFollowedAccounts(page, targetAccount, csvManager) {
        let allAccounts = [];
        let premiumAccounts = [];
        let loadMoreClicks = 0;
        let consecutiveNoNewAccounts = 0;
        
        Utils.log(`Extracting followed accounts for ${targetAccount.name}...`);
        
        while (loadMoreClicks < CONFIG.limits.maxLoadMoreClicks) {
            // Extract current accounts
            const currentAccounts = await PremiumAccountExtractor.extractPremiumAccountsFromPage(page);
            
            // Filter out accounts we already have in this session
            const newAccounts = currentAccounts.filter(account => 
                !allAccounts.some(existing => existing.userId === account.userId)
            );
            
            allAccounts.push(...newAccounts);
            
            // Separate premium accounts
            const newPremiumAccounts = PremiumAccountExtractor.filterPremiumAccounts(newAccounts);
            premiumAccounts.push(...newPremiumAccounts);
            
            // IMMEDIATE WRITE: Save new premium accounts to CSV as we find them
            if (newPremiumAccounts.length > 0) {
                csvManager.addAccountsToBatch(targetAccount, newPremiumAccounts);
                Utils.log(`💾 Immediately saved ${newPremiumAccounts.length} premium accounts to CSV`);
            }
            
            Utils.log(`📊 Extracted ${newAccounts.length} new accounts (${newPremiumAccounts.length} premium) - Total: ${allAccounts.length} (${premiumAccounts.length} premium)`);
            
            if (newAccounts.length > 0) {
                consecutiveNoNewAccounts = 0;
            } else {
                consecutiveNoNewAccounts++;
            }
            
            // Stop if we have enough premium accounts
            if (premiumAccounts.length >= CONFIG.limits.maxPremiumAccounts) {
                Utils.log(`✅ Reached premium account limit (${CONFIG.limits.maxPremiumAccounts})`);
                break;
            }
            
            // Look for "Mehr Likes laden" button
            let loadMoreButton = await page.$(CONFIG.selectors.loadMoreButton);
            
            // Try alternative selectors if primary doesn't work
            if (!loadMoreButton) {
                loadMoreButton = await page.$('.clsy-c-endlessScrolling span');
            }
            if (!loadMoreButton) {
                loadMoreButton = await page.$('[class*="endlessScrolling"] span');
            }
            if (!loadMoreButton) {
                loadMoreButton = await page.$('span:has-text("Mehr Likes laden")');
            }
            
            if (!loadMoreButton) {
                Utils.log('✅ No "Mehr Likes laden" button found - pagination complete');
                break;
            }
            
            // Check if button is visible and clickable
            const isVisible = await loadMoreButton.isVisible().catch(() => false);
            const isEnabled = await loadMoreButton.isEnabled().catch(() => false);
            
            if (!isVisible || !isEnabled) {
                Utils.log('✅ "Mehr Likes laden" button not clickable - pagination complete');
                break;
            }
            
            // Stop if we haven't found new accounts in many attempts
            if (consecutiveNoNewAccounts >= 5) {
                Utils.log('⚠️ No new accounts found in 5 consecutive attempts, stopping pagination');
                break;
            }
            
            // Click load more button
            Utils.log(`🔄 Clicking "Mehr Likes laden" button (click #${loadMoreClicks + 1})...`);
            
            try {
                await loadMoreButton.click();
                loadMoreClicks++;
                
                // Wait for new content to load
                await Utils.sleep(CONFIG.delays.loadMore);
                
            } catch (error) {
                Utils.log(`❌ Failed to click "Mehr Likes laden" button: ${error.message}`, 'warning');
                break;
            }
        }
        
        // Determine which accounts to save
        let accountsToSave = [];
        
        if (premiumAccounts.length > 0) {
            accountsToSave = premiumAccounts;
            Utils.log(`✅ Found ${premiumAccounts.length} premium accounts for ${targetAccount.name}`, 'success');
        } else {
            // No premium accounts found, get fallback normal accounts
            accountsToSave = PremiumAccountExtractor.getFallbackAccounts(allAccounts);
            Utils.log(`⚠️ No premium accounts found for ${targetAccount.name}, using ${accountsToSave.length} normal accounts as fallback`, 'warning');
        }
        
        // Save accounts to CSV
        if (accountsToSave.length > 0) {
            csvManager.addAccountsToBatch(targetAccount, accountsToSave);
        } else {
            Utils.log(`❌ No accounts found for ${targetAccount.name}`, 'error');
            // Save a record indicating no accounts found
            csvManager.addAccountsToBatch(targetAccount, [{
                name: 'NO_ACCOUNTS_FOUND',
                userId: 'N/A',
                link: 'N/A',
                isPremium: false,
                profileImageUrl: ''
            }]);
        }
        
        Utils.log(`✅ Processing complete for ${targetAccount.name}: ${accountsToSave.length} accounts saved after ${loadMoreClicks} pagination clicks`, 'success');
        return accountsToSave;
    }
    
    static async closeModal(page) {
        try {
            // Try to find and click close button
            const closeButton = await page.$(CONFIG.selectors.closeButton);
            if (closeButton) {
                await closeButton.click();
                Utils.log('Modal closed with close button');
            } else {
                // Try pressing Escape key
                await page.keyboard.press('Escape');
                Utils.log('Modal closed with Escape key');
            }
            
            await Utils.sleep(1000);
        } catch (error) {
            Utils.log(`Error closing modal: ${error.message}`, 'warning');
        }
    }
}

// Main Premium Scraper Class
class PremiumFollowedScraper {
    constructor() {
        this.csvManager = new PremiumCSVManager();
        this.stats = {
            targetAccountsProcessed: 0,
            totalPremiumAccountsFound: 0,
            totalFallbackAccountsUsed: 0,
            errors: []
        };
    }
    
    async scrapeAllTargetAccounts() {
        try {
            Utils.log('Starting premium followed accounts scraping...');
            
            // Load target accounts
            const allTargetAccounts = TargetAccountLoader.loadTargetAccounts();
            
            if (allTargetAccounts.length === 0) {
                throw new Error('No target accounts found to process');
            }
            
            // Filter out already processed accounts
            let unprocessedAccounts = allTargetAccounts.filter(account => 
                !this.csvManager.isTargetProcessed(account)
            );
            
            // Apply maxAccounts limit if specified
            if (this.maxAccounts && unprocessedAccounts.length > this.maxAccounts) {
                unprocessedAccounts = unprocessedAccounts.slice(0, this.maxAccounts);
                Utils.log(`Limited to first ${this.maxAccounts} unprocessed accounts`);
            }
            
            Utils.log(`Total accounts: ${allTargetAccounts.length}, Already processed: ${allTargetAccounts.length - unprocessedAccounts.length}, To process: ${unprocessedAccounts.length}`);
            
            if (unprocessedAccounts.length === 0) {
                Utils.log('All target accounts have already been processed!', 'success');
                return;
            }
            
            // Process accounts in sessions
            await this.processAccountsInSessions(unprocessedAccounts);
            
            // Display final summary
            this.displaySummary();
            
        } catch (error) {
            Utils.log(`Fatal error: ${error.message}`, 'error');
            throw error;
        }
    }
    
    async processAccountsInSessions(targetAccounts) {
        const totalAccounts = targetAccounts.length;
        let processedCount = 0;
        
        while (processedCount < totalAccounts) {
            const sessionAccounts = targetAccounts.slice(
                processedCount, 
                processedCount + CONFIG.session.maxAccountsPerSession
            );
            
            const sessionNumber = Math.floor(processedCount / CONFIG.session.maxAccountsPerSession) + 1;
            const totalSessions = Math.ceil(totalAccounts / CONFIG.session.maxAccountsPerSession);
            
            Utils.log(`\n🚀 Starting session ${sessionNumber}/${totalSessions} (${sessionAccounts.length} accounts)`, 'success');
            
            await this.processSession(sessionAccounts, sessionNumber);
            
            processedCount += sessionAccounts.length;
            
            // Break between sessions (except for the last one)
            if (processedCount < totalAccounts) {
                Utils.log(`💤 Session break: waiting ${CONFIG.session.sessionBreakMinutes} minutes before next session...`);
                await Utils.sleep(CONFIG.delays.sessionBreak);
            }
        }
    }
    
    async processSession(sessionAccounts, sessionNumber) {
        let browser;
        
        try {
            // Launch browser for this session
            browser = await chromium.launch({
                headless: CONFIG.browser.headless,
                slowMo: CONFIG.browser.slowMo
            });
            
            const context = await browser.newContext({
                viewport: CONFIG.browser.viewport
            });
            
            const page = await context.newPage();
            
            // Process each account in this session
            for (let i = 0; i < sessionAccounts.length; i++) {
                const targetAccount = sessionAccounts[i];
                const globalIndex = ((sessionNumber - 1) * CONFIG.session.maxAccountsPerSession) + i + 1;
                
                Utils.log(`\n=== Session ${sessionNumber} - Account ${i + 1}/${sessionAccounts.length} (Global: ${globalIndex}) ===`);
                Utils.log(`Processing: ${targetAccount.name} (ID: ${targetAccount.userId})`);
                
                try {
                    const result = await this.scrapeTargetAccount(page, targetAccount);
                    this.stats.targetAccountsProcessed++;
                    
                    // Mark as processed
                    this.csvManager.markTargetAsProcessed(
                        targetAccount, 
                        result.premiumCount, 
                        result.totalCount, 
                        'completed'
                    );
                    
                    // Wait between profiles
                    if (i < sessionAccounts.length - 1) {
                        await Utils.sleep(CONFIG.delays.betweenProfiles);
                    }
                    
                } catch (error) {
                    Utils.log(`Error processing ${targetAccount.name}: ${error.message}`, 'error');
                    this.stats.errors.push({ 
                        targetAccount: targetAccount.name, 
                        error: error.message 
                    });
                    
                    // Mark as failed
                    this.csvManager.markTargetAsProcessed(
                        targetAccount, 
                        0, 
                        0, 
                        'failed'
                    );
                    
                    // Continue with next account
                    continue;
                }
            }
            
            // Save any remaining batches after session
            this.csvManager.saveAllPendingBatches();
            
            Utils.log(`✅ Session ${sessionNumber} completed: ${sessionAccounts.length} accounts processed`, 'success');
            
        } catch (error) {
            Utils.log(`Session ${sessionNumber} error: ${error.message}`, 'error');
            throw error;
        } finally {
            if (browser) {
                await browser.close();
                Utils.log(`Browser closed for session ${sessionNumber}`);
            }
        }
    }
    
    async scrapeTargetAccount(page, targetAccount) {
        // Navigate to target account profile
        Utils.log(`Navigating to ${targetAccount.profileUrl}...`);
        await page.goto(targetAccount.profileUrl, { waitUntil: 'networkidle' });
        await Utils.sleep(CONFIG.delays.pageLoad);
        
        // Handle cookie consent if needed
        await this.handleCookieConsent(page);
        
        // Check if "mir gefallen" button exists
        const hostButton = await page.$(CONFIG.selectors.hostButton);
        if (!hostButton) {
            Utils.log(`⚠️ No "mir gefallen" button found for ${targetAccount.name} - account may not follow anyone`, 'warning');
            
            // Save a record indicating no follows
            this.csvManager.addAccountsToBatch(targetAccount, [{
                name: 'NO_FOLLOWS',
                userId: 'N/A',
                link: 'N/A',
                isPremium: false,
                profileImageUrl: ''
            }]);
            
            return { premiumCount: 0, totalCount: 0 };
        }
        
        // Open "mir gefallen" modal and extract accounts
        await PremiumModalHandler.openMirGefallenModal(page);
        const followedAccounts = await PremiumModalHandler.loadAllFollowedAccounts(page, targetAccount, this.csvManager);
        await PremiumModalHandler.closeModal(page);
        
        // Update stats
        const premiumCount = followedAccounts.filter(acc => acc.isPremium).length;
        const fallbackCount = followedAccounts.filter(acc => !acc.isPremium).length;
        const totalCount = followedAccounts.length;
        
        this.stats.totalPremiumAccountsFound += premiumCount;
        this.stats.totalFallbackAccountsUsed += fallbackCount;
        
        return { premiumCount, totalCount };
    }
    
    async handleCookieConsent(page) {
        Utils.log('🍪 Checking for cookie consent dialog...');
        
        try {
            const cookieSelectors = [
                'div[role="button"].cmp_button.cmp_button_bg.cmp_button_font_color.cmp-button-accept-all',
                'div.cmp-button-accept-all[role="button"]',
                '.cmp-button-accept-all',
                'div[role="button"]:has-text("AKZEPTIEREN UND WEITER")',
                '[class*="cmp-button-accept-all"]'
            ];
            
            await Utils.sleep(1500);
            
            for (const selector of cookieSelectors) {
                try {
                    const cookieButton = await page.$(selector);
                    if (cookieButton) {
                        const isVisible = await cookieButton.isVisible().catch(() => false);
                        if (isVisible) {
                            Utils.log(`🍪 Found cookie consent button: ${selector}`);
                            await cookieButton.click();
                            Utils.log('✅ Cookie consent accepted', 'success');
                            await Utils.sleep(1000);
                            return;
                        }
                    }
                } catch (error) {
                    continue;
                }
            }
            
            Utils.log('ℹ️ No cookie consent dialog found or already accepted');
            
        } catch (error) {
            Utils.log(`⚠️ Error handling cookie consent: ${error.message}`, 'warning');
        }
    }
    
    displaySummary() {
        const totalProcessed = this.csvManager.processedTargets.size;
        const totalPairs = this.csvManager.processedPairs.size;
        
        Utils.log('\n=== PREMIUM FOLLOWED SCRAPING SUMMARY ===');
        Utils.log(`Target accounts processed this session: ${this.stats.targetAccountsProcessed}`);
        Utils.log(`Total target accounts processed (all time): ${totalProcessed}`);
        Utils.log(`Premium accounts found this session: ${this.stats.totalPremiumAccountsFound}`);
        Utils.log(`Fallback accounts used this session: ${this.stats.totalFallbackAccountsUsed}`);
        Utils.log(`Total followed accounts extracted this session: ${this.stats.totalPremiumAccountsFound + this.stats.totalFallbackAccountsUsed}`);
        Utils.log(`Total account pairs in database: ${totalPairs}`);
        
        if (this.stats.errors.length > 0) {
            Utils.log(`Errors encountered: ${this.stats.errors.length}`, 'warning');
            this.stats.errors.slice(0, 5).forEach(error => {
                Utils.log(`${error.targetAccount}: ${error.error}`, 'error');
            });
            if (this.stats.errors.length > 5) {
                Utils.log(`... and ${this.stats.errors.length - 5} more errors`, 'warning');
            }
        }
        
        Utils.log(`Output files:`);
        Utils.log(`  - Premium followed accounts: ${CONFIG.csv.outputFilename}`);
        Utils.log(`  - Processed targets log: ${CONFIG.csv.processedFilename}`);
        Utils.log('=== SCRAPING COMPLETE ===', 'success');
    }
}

// Command line argument parsing
function parseArguments() {
    const args = process.argv.slice(2);
    const options = {
        headless: true,
        maxAccounts: null,
        sessionSize: CONFIG.session.maxAccountsPerSession
    };
    
    args.forEach(arg => {
        if (arg === '--visible' || arg === '--gui') {
            options.headless = false;
        } else if (arg.startsWith('--max=')) {
            options.maxAccounts = parseInt(arg.split('=')[1]);
        } else if (arg.startsWith('--session-size=')) {
            options.sessionSize = parseInt(arg.split('=')[1]);
        } else if (arg === '--help' || arg === '-h') {
            console.log(`
Premium Followed Scraper Usage:
  node premium-followed-scraper.js [options]

Options:
  --visible, --gui          Run with visible browser (default: headless)
  --max=N                   Process only N target accounts
  --session-size=N          Accounts per session (default: ${CONFIG.session.maxAccountsPerSession})
  --help, -h                Show this help message

Examples:
  node premium-followed-scraper.js                    # Run in headless mode
  node premium-followed-scraper.js --visible          # Run with visible browser
  node premium-followed-scraper.js --max=10           # Process only 10 accounts
  node premium-followed-scraper.js --session-size=25  # 25 accounts per session
            `);
            process.exit(0);
        }
    });
    
    return options;
}

// Main execution
async function main() {
    try {
        const options = parseArguments();
        
        // Apply command line options
        CONFIG.browser.headless = options.headless;
        if (options.sessionSize) {
            CONFIG.session.maxAccountsPerSession = options.sessionSize;
        }
        
        Utils.log(`Starting scraper with options: headless=${options.headless}, sessionSize=${CONFIG.session.maxAccountsPerSession}${options.maxAccounts ? `, maxAccounts=${options.maxAccounts}` : ''}`);
        
        const scraper = new PremiumFollowedScraper();
        scraper.maxAccounts = options.maxAccounts;
        await scraper.scrapeAllTargetAccounts();
    } catch (error) {
        Utils.log(`Script failed: ${error.message}`, 'error');
        console.error('Full error details:', error);
        process.exit(1);
    }
}

// Run the scraper
if (require.main === module) {
    main();
}

module.exports = { PremiumFollowedScraper, CONFIG };